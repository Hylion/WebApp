<?php
session_start();

class UserAuthentication
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function loginUser($ID, $password)
    {
        $errors = array();


        if (empty($ID)) {
            $errors[] = "ADMIN ID is required";
        }
        if (empty($password)) {
            $errors[] = "Password is required";
        }

        if (empty($errors)) {

            $user_check_query = "SELECT * FROM admin WHERE ID='$ID' LIMIT 1";
            $result = mysqli_query($this->db, $user_check_query);

            if (!$result) {

                $errors[] = "Query error: " . mysqli_error($this->db);
            } else {
                $user = mysqli_fetch_assoc($result);

                if ($user) {
                    if ($password == $user['Password']) {
                        $_SESSION['ID'] = $ID;
                        header("Location: admin.php");
                        exit();
                    } else {
                        $errors[] = "Wrong password";
                    }
                } else {
                    $errors[] = "ID not found";
                }
            }
        }

        return $errors;
    }
}


$db = @mysqli_connect('localhost', 'root', '', 'users');


$userAuthentication = new UserAuthentication($db);


if (isset($_POST['login_user'])) {
    $ID = mysqli_real_escape_string($db, $_POST['ID']);
    $password = mysqli_real_escape_string($db, $_POST['password']);


    $loginErrors = $userAuthentication->loginUser($ID, $password);


    foreach ($loginErrors as $error) {
        echo $error . "<br>";
    }
}
?>