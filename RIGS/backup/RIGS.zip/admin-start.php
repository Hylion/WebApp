<?php include('server2.php') ?>
<!DOCTYPE html>

<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title> Admin Login </title>

 <link rel="stylesheet" href="styles.css">
</head>
<body>
 <div class="container">
    <div> 
        <a href="login.html" class="href-go-back"> test </a>
</div>
   <input type="checkbox" id="check">
   <div class="login form">
       <div class="logo">
           <img src="logo.png" alt="Logo">
         </div>
         <form action="login-admin.php" method="post">
     <input type="text" name="ID" placeholder="ADMIN ID">
     <input type="password" name="password" placeholder="PASSWORD">
     <input type="submit" name="login_user" class="button" value="Login">
   </form>
   </div>
   </div>
 </div>     
 
</body>
</html>
<script>
  const loginForm = document.getElementById('loginForm');
  const registrationForm = document.getElementById('registrationForm');
  const signupLabel = document.getElementById('signupLabel');
  const loginLabel = document.getElementById('loginLabel');
  const check = document.getElementById('check');

  signupLabel.addEventListener('click', () => {
    registrationForm.style.display = 'block';
    loginForm.style.display = 'none';
    check.checked = true;
  });

  loginLabel.addEventListener('click', () => {
    loginForm.style.display = 'block';
    registrationForm.style.display = 'none';
    check.checked = false;
  });
</script>