<?php
require_once 'server1.php';

class userCreate {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function createUser($ID, $Password) {
        $ID_err = $Password_err = "";

        if (empty(trim($ID))) {
            $ID_err = "Please enter ID.";
        } 

        if (empty(trim($Password))) {
            $Password_err = "Please enter your Password.";
        } 

        if (empty($ID_err) && empty($Password_err)) {
            $sql = "INSERT INTO staff (ID, Password) VALUES (?, ?)";

            if ($stmt = $this->conn->prepare($sql)) {
                $stmt->bind_param("ss", $param_ID, $param_Password);

                $param_ID = $ID;
                $param_Password = $Password; 

                if ($stmt->execute()) {
                    header("location: admin.php");
                    exit();
                } else {
                    echo "Something went wrong. Please try again later.";
                }

                $stmt->close();
            }
        }
    }
}

$userCreate = new userCreate($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST["ID"];
    $Password = $_POST["Password"];

    $userCreate->createUser($ID, $Password);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
    <h2>Create User</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div>
            <label>ID:</label>
            <input type="text" name="ID" value="<?php echo isset($_POST['ID']) ? $_POST['ID'] : ''; ?>">
            <span><?php echo isset($ID_err) ? $ID_err : ''; ?></span>
        </div>
        <br>
        <div>
            <label>Password:</label>
            <input type="text" name="Password" value="<?php echo isset($_POST['Password']) ? $_POST['Password'] : ''; ?>">
            <span><?php echo isset($Password_err) ? $Password_err : ''; ?></span>
        </div>
        <div>
            <input type="submit" value="Submit">
            <input type="reset" value="Reset">
        </div>
    </form>
</div>
</body>
</html>
