<?php
require_once 'server1.php';

class StaffUpdater {
    private $conn;

    
    public function __construct($conn) {
        $this->conn = $conn;
    }

    // method to retrieve data fom staff table
    public function getStaffByID($ID) {
        $sql = "SELECT * FROM staff WHERE ID=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $ID); // "i" for integer type
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows == 1) {
            return $result->fetch_assoc();
        } else {
            return null;
        }
    }
    

 //method for updating staff table
public function updateStaff($newID, $newPassword, $ID) {
    $sql = "UPDATE staff SET ID=?, Password=? WHERE ID=?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("ssi", $newID, $newPassword, $ID); 

    if ($stmt->execute()) {
        return true;
    } else {
        error_log("Error updating staff: " . $stmt->error);
        return false;
    }
}

}

$staffUpdater = new StaffUpdater($conn);

//check if form is submited
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newID = $_POST["newID"];
    $newPassword = $_POST["newPassword"];
    $ID = $_POST["ID"];

    // Update staff information
    if ($staffUpdater->updateStaff($newID, $newPassword, $ID)) {
        echo "Staff updated successfully";
        
        header("Location: admin.php");
        exit(); 
    } else {
        echo "Error updating Staff. Please try again.";
    }
}



// fetch staff data for update
if (isset($_GET['ID'])) {
    $ID = $_GET['ID'];
    $conn_data = $staffUpdater->getStaffByID($ID);

    if (!$conn_data) {
        echo "Staff not found.";
        exit();
    }
} else {
    echo "Staff ID not provided.";
    exit();
}

var_dump($_POST);
var_dump($_GET);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Update Staff</h2>
        <a href = "admin.php"> Go back </a>
        <form method="POST" action="">
    <input type="hidden" name="ID" value="<?php echo htmlspecialchars($conn_data['ID']); ?>">
    <label>New ID:</label>
    <input type="text" name="newID"><br>
    <label>New Password:</label>
    <input type="text" name="newPassword"><br>
    <input type="submit" value="Update">
</form>
</div>
</body>
</html>
